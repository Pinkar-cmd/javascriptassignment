﻿using System;



namespace ExDelegate
{
    public delegate void HelloFunctionDelegate(string Message);

    class Program
    {
        static void Main(string[] args)
        {

            //delegate is type safe function pointer i.e both return type and parameters of the delegate function must match 
            // with the pointing function
            HelloFunctionDelegate del = new HelloFunctionDelegate(Hello);
            del("Hello from pinkar");
            Console.ReadKey();
        }

        public static void Hello(string strMessage)
        {
            Console.WriteLine(strMessage);
        }

        //public static String Hello(string strMessage)
        //{
        //    Console.WriteLine(strMessage);
        //}


    }
}
