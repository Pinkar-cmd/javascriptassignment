﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticasteDelegate
{

    public delegate void sampleDelegate();
    class Program
    {
        static void Main(string[] args)
        {
            sampleDelegate del1, del2, del3, del4;

            //singlecast delegate
            del1 = new sampleDelegate(sampleMethodOne);
            del2 = new sampleDelegate(sampleMethodTwo);
            del3 = new sampleDelegate(sampleMethodThree);

            //Multicaste delegate
            del4 = del1 + del2 + del3;
            del4();
            Console.ReadKey();
        }

        public static void sampleMethodOne()
        {
            Console.WriteLine("Sample MethodOne Invoked....");
        }

        public static void sampleMethodTwo()
        {
            Console.WriteLine("Sample MethodTwo Invoked....");
        }

        public static void sampleMethodThree()
        {
            Console.WriteLine("Sample MethodThree Invoked....");
        }


    }
}
