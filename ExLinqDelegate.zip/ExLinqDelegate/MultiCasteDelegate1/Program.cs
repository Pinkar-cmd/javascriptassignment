﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCasteDelegate1
{

    public delegate void sampleDelegate();
    class Program
    {
        static void Main(string[] args)
        {
            sampleDelegate del1 = new sampleDelegate(sampleMethodOne);
            del1 += sampleMethodTwo;
            del1 += sampleMethodThree;

            del1();
            Console.ReadKey();
        }

        public static void sampleMethodOne()
        {
            Console.WriteLine("Sample MethodOne Invoked....");
        }

        public static void sampleMethodTwo()
        {
            Console.WriteLine("Sample MethodTwo Invoked....");
        }

        public static void sampleMethodThree()
        {
            Console.WriteLine("Sample MethodThree Invoked....");
        }
    }
}
