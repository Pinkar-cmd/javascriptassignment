﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExLinqDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] names = { "pinkar", "anku", "mona", "pallavi", "juhi" };

            var mylinq = from name in names
                         where name.Contains("p")
                         select name;

            foreach(var name in mylinq)
            {
                Console.WriteLine(name+" ");
            }
            Console.ReadKey();

        }
    }
}
