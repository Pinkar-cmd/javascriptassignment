﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Simple Calculator");
            Console.WriteLine("1.Addition");
            Console.WriteLine("2.Subtraction");
            Console.WriteLine("3.Multiplication");
            Console.WriteLine("4.Division");
            Console.WriteLine("5.Exit");

            Console.WriteLine("Plz enter yr choice?....");
            int ch, num1, num2, result;
            float res1;
            ch = Convert.ToInt32(Console.ReadLine());

            switch(ch)
            {
                case 1:
                    Console.WriteLine("Enter the first no:");
                    num1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the second no:");
                    num2 = Convert.ToInt32(Console.ReadLine());
                    result = num1 + num2;
                    Console.WriteLine("Addition="+result);
                    break;

                case 2:
                    Console.WriteLine("Enter the first no:");
                    num1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the second no:");
                    num2 = Convert.ToInt32(Console.ReadLine());
                    result = Math.Abs(num1 - num2);
                    Console.WriteLine("Subtraction=" + result);
                    break;

                case 3:
                    Console.WriteLine("Enter the first no:");
                    num1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the second no:");
                    num2 = Convert.ToInt32(Console.ReadLine());
                    result = num1 * num2;
                    Console.WriteLine("Multiplication=" + result);
                    break;

                case 4:
                    Console.WriteLine("Enter the first no:");
                    num1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the second no:");
                    num2 = Convert.ToInt32(Console.ReadLine());
                    res1 = Convert.ToInt64(num1 / num2);
                    Console.WriteLine("Division=" + res1);
                    break;

                case 5:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("plz enter correct choice.");
                    break;

            }

            Console.ReadKey();
        }
    }
}
