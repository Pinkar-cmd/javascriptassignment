﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace userinfo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name?:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your age?:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your salary?:");
            float sal = Convert.ToInt64(Console.ReadLine());

            Console.WriteLine("name="+name);
            Console.WriteLine("age="+age);
            Console.WriteLine("salary="+sal);

            Console.ReadKey();
        }
    }
}
