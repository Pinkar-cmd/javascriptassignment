function changeColor(){
	let inputvalue=document.getElementById('txt1').value;
	let divbox1=document.getElementById('div1');
	let divbox2=document.getElementById('div2');

	divbox1.style.background=inputvalue;
	divbox1.addEventListener('click',function(){
		divbox2.style.background=inputvalue;
	})
}