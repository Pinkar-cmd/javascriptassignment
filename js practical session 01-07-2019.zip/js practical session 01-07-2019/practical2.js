function getURL(){
	let urlvalue=document.getElementById('txt1').value;

	let divbox1=document.getElementById('div1');
	divbox1.style.backgroundImage="url('"+urlvalue+"')";

}