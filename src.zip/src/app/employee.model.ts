export class Employee{

    EmployeeID :number;
    Name :string;
    Position : string;
    Age :number;
    Salary :number;
 }