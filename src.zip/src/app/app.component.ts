import { Component,OnInit } from '@angular/core';
import { Employee } from './employee.model';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit{

  employees : Employee[];

  constructor(private _dataservice : DataService) {}

  ngOnInit()
  {
        this.getDate();

        console.log(this.employees);        
 }
  
 getDate()
 {
    this._dataservice.getEmployees()
    .pipe()
    .subscribe(data=>
      {
        this.employees=data});
 }
}
