import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee.model';


@Injectable()
export class DataService {

  apiUrl="http://localhost:60731/api/employees";

  constructor(private _http: HttpClient) { }

  getEmployees(){
    return this._http.get<Employee[]>(this.apiUrl);
  }

}