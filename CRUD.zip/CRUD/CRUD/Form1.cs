﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=localhost;Initial Catalog=ExCRUD;User ID=sa;Password=123");
        public int studentID;

        private void Form1_Load(object sender, EventArgs e)
        {
            getStudentRecord();
        }

        private void getStudentRecord()
        {
            
            SqlCommand cmd = new SqlCommand("select * from StudentsTb", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            StudentRecorddataGridView.DataSource = dt;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO StudentsTb VALUES (@name,@FatherName,@RollNumber,@Address,@Mobile)",con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@name", txtStudentName.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@RollNumber", txtRollNumber.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("New Student Information in successfully saved in database", "saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getStudentRecord();
                resetFormControls();
            }
        }

        private bool isValid()
        {
            if (txtStudentName.Text == string.Empty)
            {
                MessageBox.Show("Student name reduired", "failed", MessageBoxButtons.OK ,MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            resetFormControls();
        }

        private void resetFormControls()
        {
            studentID = 0;

            txtStudentName.Clear();
            txtFatherName.Clear();
            txtRollNumber.Clear();
            txtAddress.Clear();
            txtMobile.Clear();

            txtStudentName.Focus();
        }

        private void StudentRecorddataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            studentID = Convert.ToInt32(StudentRecorddataGridView.SelectedRows[0].Cells[0].Value);
            txtStudentName.Text = StudentRecorddataGridView.SelectedRows[0].Cells[1].Value.ToString();
            txtFatherName.Text = StudentRecorddataGridView.SelectedRows[0].Cells[2].Value.ToString();
            txtRollNumber.Text = StudentRecorddataGridView.SelectedRows[0].Cells[3].Value.ToString();
            txtAddress.Text = StudentRecorddataGridView.SelectedRows[0].Cells[4].Value.ToString();
            txtMobile.Text = StudentRecorddataGridView.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (studentID > 0)
            {
                SqlCommand cmd = new SqlCommand("UPDATE StudentsTb SET Name=@name , FatherName=@FatherName , RollNumber=@RollNumber , Address=@Address , Mobile=@Mobile WHERE StudentID=@ID" , con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@name", txtStudentName.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@RollNumber", txtRollNumber.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                cmd.Parameters.AddWithValue("@ID", studentID);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("New Student Information in successfully saved in database", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getStudentRecord();
                resetFormControls();
            }
            else
            {
                MessageBox.Show("Please select student from table to update information", "select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
         
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (studentID > 0)
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM StudentsTb WHERE StudentID=@ID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", studentID);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Student is Deleted from System", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                getStudentRecord();
                resetFormControls();
            }
            else
            {
                MessageBox.Show("Please select student from table to delete information", "select?", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }

}
