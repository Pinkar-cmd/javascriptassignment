  //sort by name
    function sortName()
          {
              var table=$('#main-table');
              var tbody =$('#tbody');

              tbody.find('tr').sort(function(a, b) 
                   {
                      if($('#name_order').val()=='asc') 
                            {
                                return $('td:first', a).text().localeCompare($('td:first', b).text());
                             }
                       else 
                            {
                                  return $('td:first', b).text().localeCompare($('td:first', a).text());
                            }
    
                    }).appendTo(tbody);
  
               var sort_order=$('#name_order').val();
                 if(sort_order=="asc")
                  {
                      document.getElementById("name_order").value="asc";
                  }
          }

  //sort by marks
      function sortMarks() 
              {
                 var table=$('#main-table');
                 var tbody =$('#tbody');

                tbody.find('tr').sort(function(a, b) 
                       {
                          if($('#age_order').val()=='asc') 
                            {
                               return $('td:nth-child(3)', a).text().localeCompare($('td:nth-child(3)', b).text());
                            }
                           else 
                            {
                                return $(' td:nth-child(3)', b).text().localeCompare($(' td:nth-child(3)', a).text());
                            }
    
              }).appendTo(tbody);
  
                 var sort_order=$('#age_order').val();
                 if(sort_order=="asc")
                      {
                          document.getElementById("age_order").value="asc";
                      }
            }


  //inserting a value into table
  $(document).ready(function(){
        $(".insert-student").click(function(){
            var name = $("#name").val();
            var subject = $("#subject").val();
            var marks=$("#marks").val();
            var markup = "<tr><td>" + name + "</td><td>" + subject + "</td><td>" + marks + "</td><td><input type='button' value='Delete' class='remove'</td></tr>";
            $("table tbody").append(markup);
        });

  //removing already inserted value
        $(document).on('click', '.premove', function() {
        $(this).parents('tr').remove();

         });
        
  //removing dynamic inserted value
        $(document).on('click', '.remove', function() {
        $(this).parents('tr').remove();
    });

  //count total no of rows

      $(function() {
        $('.insert-student').bind('click', function() {
           var count = $('#tbody tr').length;
          $('#totalrec').html(count);
          });
       
     });
         
});