﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExFileHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"E:\dot net\file.txt";
            string data = File.ReadAllText(filePath);

            Console.WriteLine(data);
            Console.ReadKey();

        }
    }
}
